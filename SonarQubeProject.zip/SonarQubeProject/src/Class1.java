
public class Class1 {

	
	public double Div(double x, double y) {
		if (y == 0){
			return (double) 0;
		}
		return (double) (x / y);
	}
}
