import static org.junit.Assert.*;

import org.junit.Test;


public class Class1Test {

	
	@Test
	public void DivTest1() {
		Class1 passScenario = new Class1();
		Double p = passScenario.Div((double)10,(double)2);
		assertTrue(p.equals(5.0));
	}
	
	@Test
	public void DivTest2() {
		Class1 passScenario = new Class1();
		Double p = passScenario.Div((double)10,(double)0);
		assertTrue(p.equals(0.0));
	}
	
	@Test
	public void DivTest3() {
		Class1 passScenario = new Class1();
		Double p = passScenario.Div((double)10,(double)2);
		assertFalse(p.equals(4.0));
	}
	
	@Test
	public void DivTest4() {
		Class1 passScenario = new Class1();
		Double p = passScenario.Div((double)10,(double)0);
		assertFalse(p.equals(4.0));
	}
}

 