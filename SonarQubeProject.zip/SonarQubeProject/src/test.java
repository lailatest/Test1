
public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double max=2;
		for (int j=1; j <= max; j++){
			if ((max/2) < j )
				System.out.println("Yes");
			else 
				System.out.println("No");
			
		}//for loop
	}
}
